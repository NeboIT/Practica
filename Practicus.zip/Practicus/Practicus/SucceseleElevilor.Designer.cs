﻿namespace Practicus
{
    partial class SucceseleElevilor
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel2 = new System.Windows.Forms.Panel();
            this.button6 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.succeseidDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.studentidDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.absentemotivateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.absentenemotivateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.semester1notaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.semester2notaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mediasemestrialaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.student_section = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.average_media_semestriala = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.total_absente_motivate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.total_absente_nemotivate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.total_absente = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Comportament = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.succeseleSTDBindingSource8 = new System.Windows.Forms.BindingSource(this.components);
            this.schoolDataSet8 = new Practicus.SchoolDataSet8();
            this.label1 = new System.Windows.Forms.Label();
            this.succesele = new Practicus.Succesele();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.succeseleSTDBindingSource8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.schoolDataSet8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.succesele)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.Controls.Add(this.pictureBox1);
            this.panel2.Controls.Add(this.button6);
            this.panel2.Controls.Add(this.button5);
            this.panel2.Controls.Add(this.button4);
            this.panel2.Controls.Add(this.button3);
            this.panel2.Controls.Add(this.button2);
            this.panel2.Controls.Add(this.button1);
            this.panel2.Location = new System.Drawing.Point(12, 340);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(852, 239);
            this.panel2.TabIndex = 3;
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.RoyalBlue;
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.ForeColor = System.Drawing.Color.White;
            this.button6.Location = new System.Drawing.Point(37, 93);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(135, 70);
            this.button6.TabIndex = 5;
            this.button6.Text = "Evidenta Purtarii";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.RoyalBlue;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.ForeColor = System.Drawing.Color.White;
            this.button5.Location = new System.Drawing.Point(694, 3);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(135, 70);
            this.button5.TabIndex = 4;
            this.button5.Text = "Studentii TOP";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.RoyalBlue;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.ForeColor = System.Drawing.Color.White;
            this.button4.Location = new System.Drawing.Point(529, 3);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(135, 70);
            this.button4.TabIndex = 3;
            this.button4.Text = "Exportare MSWORD";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.RoyalBlue;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.Color.White;
            this.button3.Location = new System.Drawing.Point(367, 3);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(135, 70);
            this.button3.TabIndex = 2;
            this.button3.Text = "Absentele Totale";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.RoyalBlue;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(198, 3);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(135, 70);
            this.button2.TabIndex = 1;
            this.button2.Text = "Media Semestriala";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.RoyalBlue;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(37, 3);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(135, 70);
            this.button1.TabIndex = 0;
            this.button1.Text = "Filtrare Elevi";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.dataGridView1);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(12, 15);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(852, 319);
            this.panel1.TabIndex = 2;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToOrderColumns = true;
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.succeseidDataGridViewTextBoxColumn,
            this.studentidDataGridViewTextBoxColumn,
            this.absentemotivateDataGridViewTextBoxColumn,
            this.absentenemotivateDataGridViewTextBoxColumn,
            this.semester1notaDataGridViewTextBoxColumn,
            this.semester2notaDataGridViewTextBoxColumn,
            this.mediasemestrialaDataGridViewTextBoxColumn,
            this.student_section,
            this.average_media_semestriala,
            this.total_absente_motivate,
            this.total_absente_nemotivate,
            this.total_absente,
            this.Comportament});
            this.dataGridView1.DataSource = this.succeseleSTDBindingSource8;
            this.dataGridView1.Location = new System.Drawing.Point(8, 39);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(837, 271);
            this.dataGridView1.TabIndex = 1;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // succeseidDataGridViewTextBoxColumn
            // 
            this.succeseidDataGridViewTextBoxColumn.DataPropertyName = "succese_id";
            this.succeseidDataGridViewTextBoxColumn.HeaderText = "succese_id";
            this.succeseidDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.succeseidDataGridViewTextBoxColumn.Name = "succeseidDataGridViewTextBoxColumn";
            this.succeseidDataGridViewTextBoxColumn.ReadOnly = true;
            this.succeseidDataGridViewTextBoxColumn.Width = 125;
            // 
            // studentidDataGridViewTextBoxColumn
            // 
            this.studentidDataGridViewTextBoxColumn.DataPropertyName = "student_id";
            this.studentidDataGridViewTextBoxColumn.HeaderText = "student_id";
            this.studentidDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.studentidDataGridViewTextBoxColumn.Name = "studentidDataGridViewTextBoxColumn";
            this.studentidDataGridViewTextBoxColumn.Width = 125;
            // 
            // absentemotivateDataGridViewTextBoxColumn
            // 
            this.absentemotivateDataGridViewTextBoxColumn.DataPropertyName = "absente_motivate";
            this.absentemotivateDataGridViewTextBoxColumn.HeaderText = "absente_motivate";
            this.absentemotivateDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.absentemotivateDataGridViewTextBoxColumn.Name = "absentemotivateDataGridViewTextBoxColumn";
            this.absentemotivateDataGridViewTextBoxColumn.Width = 125;
            // 
            // absentenemotivateDataGridViewTextBoxColumn
            // 
            this.absentenemotivateDataGridViewTextBoxColumn.DataPropertyName = "absente_nemotivate";
            this.absentenemotivateDataGridViewTextBoxColumn.HeaderText = "absente_nemotivate";
            this.absentenemotivateDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.absentenemotivateDataGridViewTextBoxColumn.Name = "absentenemotivateDataGridViewTextBoxColumn";
            this.absentenemotivateDataGridViewTextBoxColumn.Width = 125;
            // 
            // semester1notaDataGridViewTextBoxColumn
            // 
            this.semester1notaDataGridViewTextBoxColumn.DataPropertyName = "semester1_nota";
            this.semester1notaDataGridViewTextBoxColumn.HeaderText = "semester1_nota";
            this.semester1notaDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.semester1notaDataGridViewTextBoxColumn.Name = "semester1notaDataGridViewTextBoxColumn";
            this.semester1notaDataGridViewTextBoxColumn.Width = 125;
            // 
            // semester2notaDataGridViewTextBoxColumn
            // 
            this.semester2notaDataGridViewTextBoxColumn.DataPropertyName = "semester2_nota";
            this.semester2notaDataGridViewTextBoxColumn.HeaderText = "semester2_nota";
            this.semester2notaDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.semester2notaDataGridViewTextBoxColumn.Name = "semester2notaDataGridViewTextBoxColumn";
            this.semester2notaDataGridViewTextBoxColumn.Width = 125;
            // 
            // mediasemestrialaDataGridViewTextBoxColumn
            // 
            this.mediasemestrialaDataGridViewTextBoxColumn.DataPropertyName = "media_semestriala";
            this.mediasemestrialaDataGridViewTextBoxColumn.HeaderText = "media_semestriala";
            this.mediasemestrialaDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.mediasemestrialaDataGridViewTextBoxColumn.Name = "mediasemestrialaDataGridViewTextBoxColumn";
            this.mediasemestrialaDataGridViewTextBoxColumn.ReadOnly = true;
            this.mediasemestrialaDataGridViewTextBoxColumn.Width = 125;
            // 
            // student_section
            // 
            this.student_section.DataPropertyName = "student_section";
            this.student_section.HeaderText = "student_section";
            this.student_section.MinimumWidth = 6;
            this.student_section.Name = "student_section";
            this.student_section.Width = 125;
            // 
            // average_media_semestriala
            // 
            this.average_media_semestriala.DataPropertyName = "average_media_semestriala";
            this.average_media_semestriala.HeaderText = "average_media_semestriala";
            this.average_media_semestriala.MinimumWidth = 6;
            this.average_media_semestriala.Name = "average_media_semestriala";
            this.average_media_semestriala.Width = 125;
            // 
            // total_absente_motivate
            // 
            this.total_absente_motivate.DataPropertyName = "total_absente_motivate";
            this.total_absente_motivate.HeaderText = "total_absente_motivate";
            this.total_absente_motivate.MinimumWidth = 6;
            this.total_absente_motivate.Name = "total_absente_motivate";
            this.total_absente_motivate.Width = 125;
            // 
            // total_absente_nemotivate
            // 
            this.total_absente_nemotivate.DataPropertyName = "total_absente_nemotivate";
            this.total_absente_nemotivate.HeaderText = "total_absente_nemotivate";
            this.total_absente_nemotivate.MinimumWidth = 6;
            this.total_absente_nemotivate.Name = "total_absente_nemotivate";
            this.total_absente_nemotivate.Width = 125;
            // 
            // total_absente
            // 
            this.total_absente.DataPropertyName = "total_absente";
            this.total_absente.HeaderText = "total_absente";
            this.total_absente.MinimumWidth = 6;
            this.total_absente.Name = "total_absente";
            this.total_absente.Width = 125;
            // 
            // Comportament
            // 
            this.Comportament.DataPropertyName = "Comportament";
            this.Comportament.HeaderText = "Comportament";
            this.Comportament.MinimumWidth = 6;
            this.Comportament.Name = "Comportament";
            this.Comportament.Width = 125;
            // 
            // succeseleSTDBindingSource8
            // 
            this.succeseleSTDBindingSource8.DataMember = "SucceseleSTD";
            this.succeseleSTDBindingSource8.DataSource = this.schoolDataSet8;
            // 
            // schoolDataSet8
            // 
            this.schoolDataSet8.DataSetName = "SchoolDataSet8";
            this.schoolDataSet8.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(8, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(163, 23);
            this.label1.TabIndex = 0;
            this.label1.Text = "Succesele Elevilor";
            // 
            // succesele
            // 
            this.succesele.DataSetName = "Succesele";
            this.succesele.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Practicus.Properties.Resources.school;
            this.pictureBox1.Location = new System.Drawing.Point(289, 79);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(428, 143);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // SucceseleElevilor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "SucceseleElevilor";
            this.Size = new System.Drawing.Size(876, 592);
            this.Load += new System.EventHandler(this.SucceseleElevilor_Load_1);
            this.panel2.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.succeseleSTDBindingSource8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.schoolDataSet8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.succesele)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button button1;
        private Succesele succesele;

        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;

        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.DataGridViewTextBoxColumn succeseidDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn studentidDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn absentemotivateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn absentenemotivateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn semester1notaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn semester2notaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn mediasemestrialaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn student_section;
        private System.Windows.Forms.DataGridViewTextBoxColumn average_media_semestriala;
        private System.Windows.Forms.DataGridViewTextBoxColumn total_absente_motivate;
        private System.Windows.Forms.DataGridViewTextBoxColumn total_absente_nemotivate;
        private System.Windows.Forms.DataGridViewTextBoxColumn total_absente;
        private System.Windows.Forms.DataGridViewTextBoxColumn Comportament;
        private System.Windows.Forms.BindingSource succeseleSTDBindingSource8;
        private SchoolDataSet8 schoolDataSet8;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}
