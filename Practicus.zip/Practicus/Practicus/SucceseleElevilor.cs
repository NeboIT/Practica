﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using System.Xml.Linq;
using Microsoft.Office.Interop.Word;

namespace Practicus
{
    public partial class SucceseleElevilor : UserControl
    {
        SqlConnection connect = new SqlConnection(@"Data Source=NEBO\SQLEXPRESS;Initial Catalog=School;Integrated Security=True;Connect Timeout=30");

        private SqlDataAdapter dataAdapter;
        private System.Data.DataTable dataTable;

        public SucceseleElevilor()
        {
            InitializeComponent();
        }

        private void SucceseleElevilor_Load_1(object sender, EventArgs e)
        {
            LoadPerformanceData();
        }

        public void LoadPerformanceData()
        {
            try
            {
                string query = "SELECT * FROM SucceseleSTD";
                dataAdapter = new SqlDataAdapter(query, connect);
                SqlCommandBuilder commandBuilder = new SqlCommandBuilder(dataAdapter);
                dataTable = new System.Data.DataTable();
                dataAdapter.Fill(dataTable);
                dataGridView1.DataSource = dataTable;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading data: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FilterData();
        }

        private void FilterData()
        {
            try
            {
                string query = "SELECT * FROM SucceseleSTD WHERE media_semestriala > 8.5 AND absente_nemotivate <= 40";
                dataAdapter = new SqlDataAdapter(query, connect);
                SqlCommandBuilder commandBuilder = new SqlCommandBuilder(dataAdapter);
                dataTable = new System.Data.DataTable();
                dataAdapter.Fill(dataTable);
                dataGridView1.DataSource = dataTable;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error filtering data: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            MediaPeGrupa();
        }

        public void MediaPeGrupa()
        {

            try
            {
                if (connect.State != ConnectionState.Open)
                {
                    connect.Open();
                }

                string query = @"
                    SELECT 
                        S.student_section,
                        AVG(SSTD.media_semestriala) AS average_media_semestriala
                    FROM 
                        SucceseleSTD SSTD
                    JOIN 
                        Students S ON SSTD.student_id = S.student_id
                    GROUP BY 
                        S.student_section";
                dataAdapter = new SqlDataAdapter(query, connect);
                SqlCommandBuilder commandBuilder = new SqlCommandBuilder(dataAdapter);
                dataTable = new System.Data.DataTable();
                dataAdapter.Fill(dataTable);
                dataGridView1.DataSource = dataTable;


                if (dataTable.Rows.Count == 0)
                {
                    MessageBox.Show("No data found for the specified criteria.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error fetching data: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (connect.State == ConnectionState.Open)
                {
                    connect.Close();
                }
            }
            HideEmptyColumns();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            TotalAbsentePeGrupa();
        }

        public void TotalAbsentePeGrupa()
        {
            try
            {
                if (connect.State != ConnectionState.Open)
                {
                    connect.Open();
                }

                string query = @"
                    SELECT 
                        S.student_section,
                        SUM(SSTD.absente_motivate) AS total_absente_motivate,
                        SUM(SSTD.absente_nemotivate) AS total_absente_nemotivate,
                        SUM(SSTD.absente_motivate + SSTD.absente_nemotivate) AS total_absente
                    FROM 
                        SucceseleSTD SSTD
                    JOIN 
                        Students S ON SSTD.student_id = S.student_id
                    GROUP BY 
                        S.student_section";
                dataAdapter = new SqlDataAdapter(query, connect);
                SqlCommandBuilder commandBuilder = new SqlCommandBuilder(dataAdapter);
                dataTable = new System.Data.DataTable();
                dataAdapter.Fill(dataTable);
                dataGridView1.DataSource = dataTable;

                if (dataTable.Rows.Count == 0)
                {
                    MessageBox.Show("No data found for the specified criteria.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error fetching data: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (connect.State == ConnectionState.Open)
                {
                    connect.Close();
                }
            }
            HideEmptyColumns();
        }

        private void HideEmptyColumns()
        {
            foreach (DataGridViewColumn column in dataGridView1.Columns)
            {
                bool hasData = false;
                foreach (DataGridViewRow row in dataGridView1.Rows)
                {
                    if (row.Cells[column.Name].Value != null && !string.IsNullOrWhiteSpace(row.Cells[column.Name].Value.ToString()))
                    {
                        hasData = true;
                        break;
                    }
                }
                column.Visible = hasData;
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex != -1)
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
                string succeseId = row.Cells["succese_id"].Value.ToString();
                string studentId = row.Cells["student_id"].Value.ToString();
                string absenteMotivate = row.Cells["absente_motivate"].Value.ToString();
                string absenteNemotivate = row.Cells["absente_nemotivate"].Value.ToString();
                string semester1Nota = row.Cells["semester1_nota"].Value.ToString();
                string semester2Nota = row.Cells["semester2_nota"].Value.ToString();
                string mediaSemestriala = row.Cells["media_semestriala"].Value.ToString();
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            ExportToWord();
        }

        private void ExportToWord()
        {
            try
            {
                if (dataTable == null || dataTable.Rows.Count == 0)
                {
                    MessageBox.Show("No data available to export.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }

                var highestGradeStudent = dataTable.AsEnumerable().OrderByDescending(row => row.Field<decimal>("media_semestriala")).First();
                var lowestGradeStudent = dataTable.AsEnumerable().OrderBy(row => row.Field<decimal>("media_semestriala")).First();

                Microsoft.Office.Interop.Word.Application wordApp = new Microsoft.Office.Interop.Word.Application();
                Document doc = wordApp.Documents.Add();

                Paragraph para1 = doc.Content.Paragraphs.Add();
                para1.Range.Text = "Studentul cu cea mai mare medie semestriala:";
                para1.Range.InsertParagraphAfter();

                AppendStudentData(doc, highestGradeStudent);

                Paragraph para2 = doc.Content.Paragraphs.Add();
                para2.Range.Text = "Studentul cu cea mai mica medie semestriala:";
                para2.Range.InsertParagraphAfter();

                AppendStudentData(doc, lowestGradeStudent);

                wordApp.Visible = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error exporting data to Word: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void AppendStudentData(Document doc, DataRow studentRow)
        {
            foreach (DataColumn column in dataTable.Columns)
            {
                Paragraph para = doc.Content.Paragraphs.Add();
                para.Range.Text = $"{column.ColumnName}: {studentRow[column]}";
                para.Range.InsertParagraphAfter();
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            AfiseazaListaStudentilor();
        }
        private void AfiseazaListaStudentilor()
        {
            try
            {
                string query = @"
                SELECT 
                    S.student_id,
                    S.student_name,
                    S.student_section,
                    SSTD.media_semestriala
                FROM 
                    SucceseleSTD SSTD
                JOIN 
                    Students S ON SSTD.student_id = S.student_id
                ORDER BY 
                    SSTD.media_semestriala DESC";

                dataAdapter = new SqlDataAdapter(query, connect);
                SqlCommandBuilder commandBuilder = new SqlCommandBuilder(dataAdapter);
                dataTable = new System.Data.DataTable();
                dataAdapter.Fill(dataTable);
                dataGridView1.DataSource = dataTable;
                HideEmptyColumns();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error fetching data: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            EvidentaPurtarii();
        }
        public void EvidentaPurtarii()
        {
            try
            {
                string query = @"
        SELECT 
            S.student_id,
            S.Comportament
        FROM 
            SucceseleSTD S
        JOIN 
            Students ST ON S.student_id = ST.student_id
        ORDER BY 
            S.student_id ASC";

                dataAdapter = new SqlDataAdapter(query, connect);
                SqlCommandBuilder commandBuilder = new SqlCommandBuilder(dataAdapter);
                dataTable = new System.Data.DataTable();
                dataAdapter.Fill(dataTable);
                dataGridView1.DataSource = dataTable;
                HideEmptyColumns();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error fetching data: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void succeseleSTDBindingSource5_CurrentChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}    