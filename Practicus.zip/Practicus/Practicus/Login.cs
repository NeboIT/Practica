﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Practicus
{
    public partial class Login : Form
    {
        SqlConnection connect = new SqlConnection(@"Data Source=NEBO\SQLEXPRESS;Initial Catalog=School;Integrated Security=True");
        public Login()
        {
            InitializeComponent();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            password.PasswordChar = showPass.Checked ? '*' : '\0';
        }
        
        private void label1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void loginBtn_Click(object sender, EventArgs e)
        {
            if (username.Text == "" || password.Text == "" )
            {
                MessageBox.Show("Va rugam sa completati toate campurile libere.", "Eroare", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                try
                {
                    connect.Open();

                    String selectData = "SELECT * FROM users WHERE username = @username AND password = @password";

                    using (SqlCommand cmd = new SqlCommand(selectData, connect))
                    {
                        cmd.Parameters.AddWithValue("@username", username.Text.Trim());
                        cmd.Parameters.AddWithValue("@password", password.Text.Trim());
                        SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                        DataTable table = new DataTable();
                        adapter.Fill(table);
                        
                        if (table.Rows.Count >= 1)
                        {
                            MessageBox.Show("Logare cu Succes", "Information message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        
                            MainForm mForm = new MainForm();
                            mForm.Show();
                            this.Hide();
                        }
                        else
                        {
                            MessageBox.Show("Date incorecte(username/password)", "Error message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }

                }
                catch (Exception ex)
                {
                    MessageBox.Show("Eroare la conectare cu baza de date: " + ex, "Error message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally 
                { 
                    connect.Close();
                }
                    
                
            }
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}