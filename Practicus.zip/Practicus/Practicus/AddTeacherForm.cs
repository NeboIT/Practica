﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Practicus
{
    public partial class AddTeacherForm : UserControl
    {
        SqlConnection connect = new SqlConnection(@"Data Source=NEBO\SQLEXPRESS;Initial Catalog=School;Integrated Security=True;Connect Timeout=30");

        private SqlDataAdapter dataAdapter;
        private DataTable dataTable;

        public AddTeacherForm()
        {
            InitializeComponent();
        }

        private void AddTeacherForm_Load(object sender, EventArgs e)
        {
            LoadTeacherData();
        }

        public void LoadTeacherData()
        {
            string query = "SELECT * FROM Profesori";
            dataAdapter = new SqlDataAdapter(query, connect);
            SqlCommandBuilder commandBuilder = new SqlCommandBuilder(dataAdapter);
            dataTable = new DataTable();
            dataAdapter.Fill(dataTable);
            dataGridView1.DataSource = dataTable;
        }

      

        

        public void ClearFields()
        {
            profesor_id.Text = "";
            profesor_name.Text = "";
            profesor_gender.SelectedIndex = -1;
            profesor_address.Text = "";
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex != -1)
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
                profesor_id.Text = row.Cells["profesor_id"].Value.ToString();
                profesor_name.Text = row.Cells["profesor_name"].Value.ToString();
                profesor_gender.Text = row.Cells["profesor_gender"].Value.ToString();
                profesor_address.Text = row.Cells["profesor_address"].Value.ToString();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(profesor_id.Text) ||
               string.IsNullOrWhiteSpace(profesor_name.Text) ||
               string.IsNullOrWhiteSpace(profesor_gender.Text) ||
               string.IsNullOrWhiteSpace(profesor_address.Text))
            {
                MessageBox.Show("Please fill all blank fields", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                if (connect.State != ConnectionState.Open)
                {
                    connect.Open();
                }

                try
                {
                    string checkTeacherID = "SELECT COUNT(*) FROM Profesori WHERE profesor_id = @profesorID";
                    using (SqlCommand checkTID = new SqlCommand(checkTeacherID, connect))
                    {
                        checkTID.Parameters.AddWithValue("@profesorID", profesor_id.Text.Trim());
                        int count = (int)checkTID.ExecuteScalar();

                        if (count >= 1)
                        {
                            MessageBox.Show("Teacher ID: " + profesor_id.Text.Trim() + " already exists", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                        else
                        {
                            DateTime today = DateTime.Today;
                            string insertData = "INSERT INTO Profesori (profesor_id, profesor_name, profesor_gender, profesor_address, date_insert) " +
                                                "VALUES(@profesorID, @profesorName, @profesorGender, @profesorAddress, @dateInsert)";

                            using (SqlCommand cmd = new SqlCommand(insertData, connect))
                            {
                                cmd.Parameters.AddWithValue("@profesorID", profesor_id.Text.Trim());
                                cmd.Parameters.AddWithValue("@profesorName", profesor_name.Text.Trim());
                                cmd.Parameters.AddWithValue("@profesorGender", profesor_gender.Text.Trim());
                                cmd.Parameters.AddWithValue("@profesorAddress", profesor_address.Text.Trim());
                                cmd.Parameters.AddWithValue("@dateInsert", today);

                                cmd.ExecuteNonQuery();

                                LoadTeacherData();

                                MessageBox.Show("Added successfully!", "Information Message", MessageBoxButtons.OK, MessageBoxIcon.Information);

                                ClearFields();
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error connecting Database: " + ex.Message, "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    connect.Close();
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            {
                if (string.IsNullOrWhiteSpace(profesor_id.Text) ||
                    string.IsNullOrWhiteSpace(profesor_name.Text) ||
                    string.IsNullOrWhiteSpace(profesor_gender.Text) ||
                    string.IsNullOrWhiteSpace(profesor_address.Text))
                {
                    MessageBox.Show("Please fill all blank fields", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    try
                    {
                        if (connect.State != ConnectionState.Open)
                        {
                            connect.Open();
                        }

                        string updateData = "UPDATE Profesori SET profesor_name = @profesorName, profesor_gender = @profesorGender, profesor_address = @profesorAddress " +
                                            "WHERE profesor_id = @profesorID";

                        using (SqlCommand cmd = new SqlCommand(updateData, connect))
                        {
                            cmd.Parameters.AddWithValue("@profesorID", profesor_id.Text.Trim());
                            cmd.Parameters.AddWithValue("@profesorName", profesor_name.Text.Trim());
                            cmd.Parameters.AddWithValue("@profesorGender", profesor_gender.Text.Trim());
                            cmd.Parameters.AddWithValue("@profesorAddress", profesor_address.Text.Trim());

                            cmd.ExecuteNonQuery();

                            LoadTeacherData();

                            MessageBox.Show("Updated successfully!", "Information Message", MessageBoxButtons.OK, MessageBoxIcon.Information);

                            ClearFields();
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error updating Database: " + ex.Message, "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    finally
                    {
                        connect.Close();
                    }
                }
            }

        }

        private void button4_Click(object sender, EventArgs e)
        {
             ClearFields();
        }

        private void button5_Click(object sender, EventArgs e)
        {
                if (string.IsNullOrWhiteSpace(profesor_id.Text))
                {
                    MessageBox.Show("Please select a teacher to delete", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    try
                    {
                        if (connect.State != ConnectionState.Open)
                        {
                            connect.Open();
                        }

                        string deleteData = "DELETE FROM Profesori WHERE profesor_id = @profesorID";

                        using (SqlCommand cmd = new SqlCommand(deleteData, connect))
                        {
                            cmd.Parameters.AddWithValue("@profesorID", profesor_id.Text.Trim());

                            cmd.ExecuteNonQuery();

                            LoadTeacherData();

                            MessageBox.Show("Deleted successfully!", "Information Message", MessageBoxButtons.OK, MessageBoxIcon.Information);

                            ClearFields();
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error deleting from Database: " + ex.Message, "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    finally
                    {
                        connect.Close();
                    }
                }           
        }
    }
}

