﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Practicus
{
    public partial class AddStudentsForm : UserControl
    {
        SqlConnection connect = new SqlConnection(@"Data Source=NEBO\SQLEXPRESS;Initial Catalog=School;Integrated Security=True;Connect Timeout=30");

        private SqlDataAdapter dataAdapter;
        private DataTable dataTable;

        public AddStudentsForm()
        {
            InitializeComponent();
        }

        private void AddStudentsForm_Load(object sender, EventArgs e)
        {
            LoadStudentData();
        }

        public void LoadStudentData()
        {
            string query = "SELECT * FROM students";
            dataAdapter = new SqlDataAdapter(query, connect);
            SqlCommandBuilder commandBuilder = new SqlCommandBuilder(dataAdapter);
            dataTable = new DataTable();
            dataAdapter.Fill(dataTable);
            dataGridView1.DataSource = dataTable;
        }



        private void button2_Click_1(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(student_id.Text) ||
                string.IsNullOrWhiteSpace(student_name.Text) ||
                string.IsNullOrWhiteSpace(student_gender.Text) ||
                string.IsNullOrWhiteSpace(student_address.Text) ||
                string.IsNullOrWhiteSpace(student_grade.Text) ||
                string.IsNullOrWhiteSpace(comboBox3.Text) ||
                string.IsNullOrWhiteSpace(student_status.Text))
            {
                MessageBox.Show("Please fill all blank fields", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                if (connect.State != ConnectionState.Open)
                {
                    connect.Open();
                }

                try
                {
                    // Verificăm dacă student_id există deja
                    string checkStudentID = "SELECT COUNT(*) FROM students WHERE student_id = @studentID";
                    using (SqlCommand checkSID = new SqlCommand(checkStudentID, connect))
                    {
                        checkSID.Parameters.AddWithValue("@studentID", student_id.Text.Trim());
                        int count = (int)checkSID.ExecuteScalar();

                        if (count >= 1)
                        {
                            MessageBox.Show("Student ID: " + student_id.Text.Trim() + " already exists", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                        else
                        {
                            DateTime today = DateTime.Today;
                            string insertData = "INSERT INTO students (student_id, student_name, student_gender, student_address, student_grade, student_section, student_status, date_insert) " +
                                                "VALUES(@studentID, @studentName, @studentGender, @studentAddress, @studentGrade, @studentSection, @studentStatus, @dateInsert)";

                            using (SqlCommand cmd = new SqlCommand(insertData, connect))
                            {
                                cmd.Parameters.AddWithValue("@studentID", student_id.Text.Trim());
                                cmd.Parameters.AddWithValue("@studentName", student_name.Text.Trim());
                                cmd.Parameters.AddWithValue("@studentGender", student_gender.Text.Trim());
                                cmd.Parameters.AddWithValue("@studentAddress", student_address.Text.Trim());
                                cmd.Parameters.AddWithValue("@studentGrade", student_grade.Text.Trim());
                                cmd.Parameters.AddWithValue("@studentSection", comboBox3.Text.Trim());
                                cmd.Parameters.AddWithValue("@studentStatus", student_status.Text.Trim());
                                cmd.Parameters.AddWithValue("@dateInsert", today);

                                cmd.ExecuteNonQuery();

                                // Refresh DataGridView after insert
                                LoadStudentData();

                                MessageBox.Show("Added successfully!", "Information Message", MessageBoxButtons.OK, MessageBoxIcon.Information);

                                ClearFields();
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error connecting Database: " + ex.Message, "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    connect.Close();
                }
            }
        }
        private void button3_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(student_id.Text) ||
                string.IsNullOrWhiteSpace(student_name.Text) ||
                string.IsNullOrWhiteSpace(student_gender.Text) ||
                string.IsNullOrWhiteSpace(student_address.Text) ||
                string.IsNullOrWhiteSpace(student_grade.Text) ||
                string.IsNullOrWhiteSpace(comboBox3.Text) ||
                string.IsNullOrWhiteSpace(student_status.Text))
            {
                MessageBox.Show("Please fill all blank fields", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                try
                {
                    if (connect.State != ConnectionState.Open)
                    {
                        connect.Open();
                    }

                    string updateData = "UPDATE students SET student_name = @studentName, student_gender = @studentGender, student_address = @studentAddress, " +
                                        "student_grade = @studentGrade, student_section = @studentSection, student_status = @studentStatus " +
                                        "WHERE student_id = @studentID";

                    using (SqlCommand cmd = new SqlCommand(updateData, connect))
                    {
                        cmd.Parameters.AddWithValue("@studentID", student_id.Text.Trim());
                        cmd.Parameters.AddWithValue("@studentName", student_name.Text.Trim());
                        cmd.Parameters.AddWithValue("@studentGender", student_gender.Text.Trim());
                        cmd.Parameters.AddWithValue("@studentAddress", student_address.Text.Trim());
                        cmd.Parameters.AddWithValue("@studentGrade", student_grade.Text.Trim());
                        cmd.Parameters.AddWithValue("@studentSection", comboBox3.Text.Trim());
                        cmd.Parameters.AddWithValue("@studentStatus", student_status.Text.Trim());

                        cmd.ExecuteNonQuery();

                        LoadStudentData();

                        MessageBox.Show("Updated successfully!", "Information Message", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        ClearFields();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error updating Database: " + ex.Message, "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    connect.Close();
                }
            }
        }

        public void ClearFields()
        {
            student_id.Text = "";
            student_name.Text = "";
            student_gender.SelectedIndex = -1;
            student_address.Text = "";
            student_grade.SelectedIndex = -1;
            comboBox3.SelectedIndex = -1;
            student_status.SelectedIndex = -1;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex != -1)
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
                student_id.Text = row.Cells["student_id"].Value.ToString();
                student_name.Text = row.Cells["student_name"].Value.ToString();
                student_gender.Text = row.Cells["student_gender"].Value.ToString();
                student_address.Text = row.Cells["student_address"].Value.ToString();
                student_grade.Text = row.Cells["student_grade"].Value.ToString();
                comboBox3.Text = row.Cells["student_section"].Value.ToString();
                student_status.Text = row.Cells["student_status"].Value.ToString();
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            ClearFields();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(student_id.Text))
            {
                MessageBox.Show("Please select a student to delete", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                try
                {
                    if (connect.State != ConnectionState.Open)
                    {
                        connect.Open();
                    }

                    string deleteData = "DELETE FROM students WHERE student_id = @studentID";

                    using (SqlCommand cmd = new SqlCommand(deleteData, connect))
                    {
                        cmd.Parameters.AddWithValue("@studentID", student_id.Text.Trim());

                        cmd.ExecuteNonQuery();

                        LoadStudentData();

                        MessageBox.Show("Deleted successfully!", "Information Message", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        ClearFields();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error deleting from Database: " + ex.Message, "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    connect.Close();
                }
            }
        }

        public void LoadRestantieriData()
        {
            string query = "SELECT * FROM students WHERE student_status = 'Restantier' ORDER BY student_name ASC";
            dataAdapter = new SqlDataAdapter(query, connect);
            SqlCommandBuilder commandBuilder = new SqlCommandBuilder(dataAdapter);
            dataTable = new DataTable();
            dataAdapter.Fill(dataTable);
            dataGridView1.DataSource = dataTable;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            LoadRestantieriData();
        }
    }
    
}
