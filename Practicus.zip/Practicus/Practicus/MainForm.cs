﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Practicus
{
    public partial class MainForm : Form
    {
        private DashboardForm dashboardForm1;

        public MainForm()
        {
            InitializeComponent();
            InitializeDashboardForm();
        }

        private void InitializeDashboardForm()
        {
            
            dashboardForm1 = new DashboardForm();
            dashboardForm1.Visible = false; 
            this.Controls.Add(dashboardForm1);

        }

        private void label2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            DialogResult check = MessageBox.Show("Esti sigur ca vrei sa iesi?", "Confirmation message", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (check == DialogResult.Yes)
            {
                Login lForm = new Login();
                lForm.Show();
                this.Hide();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            dashboardForm1.Visible = true;
            addStudentsForm1.Visible = false;
            addTeacherForm1.Visible = false;
            succeseleElevilor1.Visible = false;


        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            succeseleElevilor1.Visible = false;
            dashboardForm1.Visible = false;
            addTeacherForm1.Visible = false;
            addStudentsForm1.Visible= true;

        }

        private void button3_Click(object sender, EventArgs e)
        {
            succeseleElevilor1.Visible = false;
            dashboardForm1.Visible = false;
            addStudentsForm1.Visible = false;
            addTeacherForm1.Visible = true;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            dashboardForm1.Visible = false;
            addStudentsForm1.Visible = false;
            addTeacherForm1.Visible = false;
            succeseleElevilor1.Visible = true;
        }
    }
}
